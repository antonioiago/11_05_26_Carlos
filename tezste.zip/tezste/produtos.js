// produtos.js

// Pegamos os elementos corretos do Produto.html
const form = document.getElementById("formProduto");
const tabela = document.getElementById("tabelaProdutos");

// Iniciamos a lista pegando o que já existe no armazenamento do navegador
let produtos = JSON.parse(localStorage.getItem("meus_produtos")) || [];

function renderizarProdutos() {
  tabela.innerHTML = "";

  produtos.forEach((prod, index) => {
    tabela.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${prod.nome}</td>
        <td>R$ ${parseFloat(prod.preco).toFixed(2)}</td>
        <td>${prod.estoque}</td>
        <td>${prod.categoria}</td>
        <td>
          <button class="btnExcluir" onclick="excluirProduto(${index})">
            Excluir
          </button>
        </td>
      </tr>
    `;
  });
}

// Escutamos o envio do formulário de produtos
form.addEventListener("submit", (e) => {
  e.preventDefault();

  // Pegamos os valores dos IDs específicos do seu HTML de Produtos
  const novoProduto = {
    nome: document.getElementById("nomeProduto").value,
    preco: document.getElementById("precoProduto").value,
    estoque: document.getElementById("estoqueProduto").value,
    categoria: document.getElementById("categoriaProduto").value,
  };

  produtos.push(novoProduto);

  // Salva no navegador (LocalStorage)
  localStorage.setItem("meus_produtos", JSON.stringify(produtos));
  
  renderizarProdutos();
  form.reset(); 
});

function excluirProduto(index) {
  if(confirm("Deseja remover este produto?")) {
    produtos.splice(index, 1);
    localStorage.setItem("meus_produtos", JSON.stringify(produtos));
    renderizarProdutos();
  }
}

// Carrega os itens salvos assim que a página abre
renderizarProdutos();
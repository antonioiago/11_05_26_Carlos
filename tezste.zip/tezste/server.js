const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'roupas'
});

db.connect();

app.post('/usuarios', (req, res) => {
    const { nome, telefone } = req.body;
    db.query('INSERT INTO Usuario (nome, telefone) VALUES (?, ?)', [nome, telefone], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(200);
    });
});

app.get('/produtos', (req, res) => {
    db.query('SELECT * FROM Produto', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/produtos', (req, res) => {
    const { nome, preco, estoque, categoria } = req.body;
    db.query('INSERT INTO Produto (nome, preco, estoque, categoria) VALUES (?, ?, ?, ?)', 
    [nome, preco, estoque, categoria], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(200);
    });
});

app.delete('/produtos/:id', (req, res) => {
    db.query('DELETE FROM Produto WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(200);
    });
});

app.listen(3000);